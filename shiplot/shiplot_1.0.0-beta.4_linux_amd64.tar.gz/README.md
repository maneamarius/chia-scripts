# shiplot

[![codecov](https://codecov.io/gh/tcpaddock/shiplot/branch/alpha/graph/badge.svg?token=N52TPZ8AWX)](https://app.codecov.io/gh/tcpaddock/shiplot/tree/alpha)

Chia plot file shipper.

## Features

- Move plots locally or ship plots over the network.
- Dynamically adjusts number of plot transfers based on available destination paths.
- Keeps track of destination paths and queues as needed.
- Supports multiple source and destination paths.
- Supports path globbing to keep configs small.
- Cross platform with testing on Windows, Linux, and Mac.

## Install

- Download the binary from [releases](https://github.com/tcpaddock/shiplot/releases).
- Create a config file in same directory as binary. (See [example](example.shiplot.yaml))

## Usage

The tool currently has two primary modes. It will either move plots locally or ship them across the network.

View the help text by running:
```bash
# Linux/macOS
shiplot help

# Windows
shiplot.exe help
```

View the version by running:
```bash
# Linux/macOS
shiplot version

# Windows
shiplot.exe version
```

### Local 

Start moving plots:
```bash
# Linux/macOS
shiplot run --maxThreads=12 --stagingPaths="/staging/*" --destinationPaths="/mnt/dest,/mnt/jbod*"

# Windows
shiplot.exe run --maxThreads=12 --stagingPaths="C:/staging/*" --destinationPaths="D:/,E:/"
```

### Network

In network mode, the destinationPaths parameter is ignored.

Start server on destination:
```bash
# Linux/macOS
shiplot run --maxThreads=12 --destinationPaths="/mnt/dest,/mnt/jbod*" --server.enabled=true

# Windows
shiplot.exe run --maxThreads=12 --destinationPaths="D:/,E:/" --server.enabled=true
```

Start client on plotter:
```bash
# Linux/macOS
shiplot run --maxThreads=12 --stagingPaths="/staging/*" --client.enabled=true --client.serverIp="192.168.0.2"

# Windows
shiplot.exe run --maxThreads=12 --stagingPaths="/staging/*" --client.enabled=true --client.serverIp="192.168.0.2"
```

## License

Licensed under the [MIT license](LICENSE).

Copyright © 2023 Taylor Paddock
